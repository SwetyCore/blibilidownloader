import re
import json
import os
import time
from videoinfo import dyjsonget,fjapi,reqhtml,defaultget,fjjsonget
from log1 import l
from download import download



def replacechar(char, charn, text):
    '''
    替换所有指定字符
    :param char: 被替换字符
    :param charn: 新字符
    :param text: 要替换的文本
    :return: 新文本
    '''
    while char in text:
        text = text.replace(char, charn)
    return text




def videoMaker(path, name):
    if ffmpeg == 'y':
        cmd = f'ffmpeg -i {path}{name}.mp3 -i {path}{name}.mp4 -vcodec copy -acodec copy {path}{name}01.mp4'
        l.info(f'Run command {cmd}')
        try:
            os.system(cmd)
            time.sleep(1)
            os.remove(f'{path}{name}.mp3')
            os.remove(f'{path}{name}.mp4')
        except Exception as msg:
            l.error(msg)


def printverson():
    pic = ''' 
     ____ _____ _      _____      __      __
    |  _ \_   _| |    |_   _|     \ \    / /
    | |_) || | | |      | |        \ \  / /  
    |  _ < | | | |      | |   --    \ \/ /  
    | |_) || |_| |____ _| |_         \  /  
    |____/_____|______|_____|         \/                                    
     _____   ______          ___   _ _      ____          _____  
    |  __ \ / __ \ \        / / \ | | |    / __ \   /\   |  __ \ 
    | |  | | |  | \ \  /\  / /|  \| | |   | |  | | /  \  | |  | | 
    | |  | | |  | |\ \/  \/ / | . ` | |   | |  | |/ /\ \ | |  | |  
    | |__| | |__| | \  /\  /  | |\  | |___| |__| / ____ \| |__| | 
    |_____/ \____/   \/  \/   |_| \_|______\____/_/    \_\_____/ '''
    selfinfo = '''ver :1.0.4
    author :SwetyCore
    introduction :一个下载b站视频的小程序。
    已知问题：不能下载番剧，直播，电影，付费视频。
    
    更新：可下载带分p的视频'''
    print(f'{pic}\n{selfinfo}')

def getsort():
    ''

def fpget(bvid,data):
    '''
    分p下载
    :return:
    '''
    se = input('请输入需要下载的集数\n eg 1-3  ：')
    se = se.split('-')
    while len(se) != 2:
        print('Error input,plese try again!')
        se = input('请输入需要下载的集数\n eg 1-3  ：')

    s = int(se[0])
    e = int(se[1])+1
    for i in range(s, e):
        l.info(f'正在下载第{i}p，共{e - s}p')
        pageurl='https://www.bilibili.com/video/'+f'{bvid}?p={i}'
        info=defaultget(pageurl)
        jsonData = json.loads(info)
        data1 = jsonData['data']
        video = data1['dash']['video'][0]['baseUrl']
        audio = data1['dash']['audio'][0]['baseUrl']
        name= data[i-1]['part']
        chardict = {
                     ' ': '',
                     '/': '-',
                     '\\': '-',
            '，':'',
            '|':''
                    }
        for key,value in chardict.items():
            name=replacechar(key,value,name)

        urllist = [video, audio,name]
        download(video,path=f'{path}{name}.mp4')
        download(audio,path=f'{path}{name}.mp3')
        videoMaker(path, name)


def dfget(bvid,data):
    pageurl = 'https://www.bilibili.com/video/' + f'{bvid}'
    info = defaultget(pageurl)
    jsonData = json.loads(info)
    data1 = jsonData['data']
    video = data1['dash']['video'][0]['baseUrl']
    audio = data1['dash']['audio'][0]['baseUrl']
    name = data['part']
    chardict = {
        ' ': '',
        '/': '-',
        '\\': '-',
        '，': '',
        '|': ''
    }
    for key, value in chardict.items():
        name = replacechar(key, value, name)

    urllist = [video, audio, name]
    download(video, path=f'{path}{name}.mp4')
    download(audio, path=f'{path}{name}.mp3')
    videoMaker(path, name)







def mainfunc():
    bvid=''
    if 'BV' in url:
        s=url.find("BV")
        bvid=url[s:s+12:]
        print(bvid)
        reqjson=json.loads(reqhtml(f'https://api.bilibili.com/x/player/pagelist?bvid={bvid}&jsonp=jsonp'))
        data=reqjson['data']
        if len(data)!=1:
            i=1
            cidlist=[]
            for videoinfo in data:
                print(f'[{i}]-{videoinfo["part"]}')
                i+=1
                cidlist.append(videoinfo['cid'])
            fpget(bvid,data)
        else:
            #无分p
            dfget(bvid,data)

            ''
    else:
        html=reqhtml(url)
        # print(html)
        bvid=re.search(r'"bvid":"(.*?)"',html,re.S).group(1)
        fjjson=fjjsonget(bvid)
        data = fjjson['data']
        if data["videos"]!=1:
            title=data['title']
            #多集
            print(f'共 {data["videos"]} 集')
            stat = data['stat']
            aid = stat['aid']
            cidjson=json.loads(reqhtml(f'https://www.bilibili.com/widget/getPageList?aid={aid}'))
            # print(cidjson)
            se = input('请输入需要下载的集数\n eg 1-3  ：')
            se = se.split('-')
            while len(se) != 2:
                print('Error input,plese try again!')
                se = input('请输入需要下载的集数\n eg 1-3  ：')

            s = int(se[0])
            e = int(se[1]) + 1
            for i in range(s, e):
                name=f'{i}-{title}'
                l.info(f'正在下载第{i}p，共{e - s}p')
                aid = stat['aid']
                cidjson = json.loads(reqhtml(f'https://www.bilibili.com/widget/getPageList?aid={aid}'))
                cid = cidjson[i-1]['cid']
                dyjson = dyjsonget(fjapi, cid)
                # print(dyjson)
                print(dyjson)
                data1 = dyjson
                video = data1['dash']['video'][0]['baseUrl']
                audio = data1['dash']['audio'][0]['baseUrl']
                chardict = {
                    ' ': '',
                    '/': '-',
                    '\\': '-',
                    '，': '',
                    '|': ''
                }
                for key, value in chardict.items():
                    name = replacechar(key, value, name)

                urllist = [video, audio, name]
                download(video, path=f'{path}{name}.mp4')
                download(audio, path=f'{path}{name}.mp3')
                videoMaker(path, name)
        else:
            name=data['title']
            print(name)
            l.info('仅1集。')
            stat=data['stat']
            aid=stat['aid']
            cidjson=json.loads(reqhtml(f'https://www.bilibili.com/widget/getPageList?aid={aid}'))
            cid=cidjson[0]['cid']
            dyjson=dyjsonget(fjapi,cid)
            # print(dyjson)
            print(dyjson)
            data1 = dyjson
            video = data1['dash']['video'][0]['baseUrl']
            audio = data1['dash']['audio'][0]['baseUrl']
            chardict = {
                ' ': '',
                '/': '-',
                '\\': '-',
                '，': '',
                '|': ''
            }
            for key, value in chardict.items():
                name = replacechar(key, value, name)

            urllist = [video, audio, name]
            download(video, path=f'{path}{name}.mp4')
            download(audio, path=f'{path}{name}.mp3')
            videoMaker(path,name)
        #番剧
        ''

    ''


if __name__ == '__main__':
    # ffmpeg=''
    # path='./'

    # # url='https://www.bilibili.com/video/BV1Eb411u7Fw'#多集普通视频
    # # url='https://www.bilibili.com/bangumi/play/ss26826/'#电影
    # # url='https://www.bilibili.com/bangumi/play/ss5630/'#单集番剧
    # url='https://www.bilibili.com/bangumi/play/ep102846'# 多集番剧
    # mainfunc()



    printverson()
    l.info('Starting program...')

    # 初始化参数
    ffmpeg = input('ffmpeg ? (y/n)：')
    url = input('视频url：')
    path = input('保存位置：')
    while path[-1::] != '/':
        l.error('位置格式错误！')
        path = input('保存位置：')
    mainfunc()
    input('Press enter to continue..')

