import requests
import json
import time
import re
from log1 import l



fjapi = 'https://api.bilibili.com/pgc/player/web/playurl'


def dyjsonget(url,cid):

    body = {
        'cid': cid,
        'qn': 80,
        'otype': 'json',
        'fnver': 0,
        'fnval': 80,
        # 'fourk': 1,
        # 'bvid': 'BV1Nb411t7yC',
        # 'ep_id': 267951,
        # 'type': '',
        # 'session': '2e6bbdb97efc560b25c9ae9eb881467e'
    }
    nbody = ''

    for key, value in body.items():
        nbody = f'{nbody}&{key}={value}'

    url = f'{url}?{nbody}'
    headers = {
        'origin': 'https://www.bilibili.com',
        'referer': 'https://www.bilibili.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36 Edg/86.0.622.68'
    }
    response = requests.get(url=url, headers=headers)
    text = response.content.decode()
    jsonText = json.loads(text)
    fjresult = jsonText['result']
    if jsonText['message'] != 'success':
        fjresult = 'error'
        l.error(jsonText['message'])
    else:
        l.info(f"Request message: {jsonText['message']}")
    return fjresult



def fjjsonget(bvid):
    api=f'https://api.bilibili.com/x/web-interface/view?bvid={bvid}'
    fjjson=json.loads(reqhtml(api))
    return fjjson

# result=fjjsonget(url=fjapi,cid=246884133)
# dash=result['dash']
# video=dash['video']
# quality=fjresult['accept_description']
# print(quality)
# print(video)


def defaultget(url):
    headers = {
        'origin': 'https://www.bilibili.com',
        'referer': 'https://www.bilibili.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36 Edg/86.0.622.68'
    }
    response = requests.get(url, headers=headers)
    html=response.content.decode()
    rule1 = re.compile(r'<script>window.__playinfo__=(.*?)</script>', re.S)
    name = re.findall(r'<span class="tit tr-fix">(.*?)</span>', html)
    info = re.findall(rule1, html)[0]
    return info




def reqhtml(url):
    headers = {
        'origin': 'https://www.bilibili.com',
        'referer': 'https://www.bilibili.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36 Edg/86.0.622.68'
    }
    response = requests.get(url, headers=headers)
    html=response.content.decode()
    return html

# print(defaultget('https://www.bilibili.com/video/BV1gV411a7GP'))